export class CashFlowGroup {
  id: number = 0;
  cashFlowGroupName: string = '';
  cashFlowGroupNote: string = '';
}
