import { Cost } from './cost';

describe('Cost', () => {
  it('should create an instance', () => {
    expect(new Cost()).toBeTruthy();
  });
});
