export class Dev {
  id: number = 0;
  devName: string = '';
}
