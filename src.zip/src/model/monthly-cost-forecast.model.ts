export interface MonthlyCostForecast {
  year_month: string;
  paid_sum: number;
  unpaid_sum: number;
  total_sum: number;
}
