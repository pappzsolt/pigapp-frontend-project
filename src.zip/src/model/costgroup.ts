export class CostGroup {
  id: number = 0;
  costGroupName: string = '';
  costGroupNote: string = '';
}
