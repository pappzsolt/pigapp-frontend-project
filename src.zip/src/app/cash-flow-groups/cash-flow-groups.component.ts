import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cash-flow-groups',
  standalone: true,
  imports: [],
  templateUrl: './cash-flow-groups.component.html',
  styleUrl: './cash-flow-groups.component.css',
})
export class CashFlowGroupsComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
}
