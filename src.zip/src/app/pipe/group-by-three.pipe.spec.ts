import { GroupByThreePipe } from './group-by-three.pipe';

describe('GroupByThreePipe', () => {
  it('create an instance', () => {
    const pipe = new GroupByThreePipe();
    expect(pipe).toBeTruthy();
  });
});
