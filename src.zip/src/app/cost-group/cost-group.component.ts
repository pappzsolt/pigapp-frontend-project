import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cost-group',
  imports: [],
  templateUrl: './cost-group.component.html',
  styleUrl: './cost-group.component.css',
})
export class CostGroupComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
}
