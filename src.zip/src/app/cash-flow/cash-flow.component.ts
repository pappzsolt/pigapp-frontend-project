import { Component, OnInit, Input, inject } from '@angular/core';
import { Cashflow, CashFlowResponse } from '../../model/cashflow';
import { Observable, of } from 'rxjs';
import { CashFlowServiceService } from '../services/cash-flow.service.service';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { CashflowTableComponent } from '../cash-flow/cashflow-table/cashflow-table.component';
import { map } from 'rxjs/operators';
import { TailwindStyledSelectDirective } from '../shared/directives/tailwind-styled-select.directive';
import { StyledInputDirective } from '../shared/directives/styled-input.directive';
import { ButtonDirective } from '../shared/directives/button.directive';
type FieldType = 'text' | 'number' | 'date' | 'select';

interface FieldConfig {
  label: string;
  controlName: string;
  type: FieldType;
  options?: any[]; // csak select típushoz
  optionLabel?: string; // csak select típushoz
}

@Component({
  selector: 'app-cash-flow',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    CashflowTableComponent,
    TailwindStyledSelectDirective,
    StyledInputDirective,
    ButtonDirective,
  ],
  templateUrl: './cash-flow.component.html',
  styleUrl: './cash-flow.component.css',
})
export class CashFlowComponent implements OnInit {
  invoices: any[] = [];
  devs: any[] = [];
  cashFlowGroups: any[] = [];
  cashFlowResponse: CashFlowResponse[] = [];
  cashFlowForm!: FormGroup;
  fieldConfigs: FieldConfig[] = [];
  @Input()
  cashflowIndex!: number;

  cashflows$: Observable<Cashflow[]> = of([]);

  // cashflowActual$: Observable<Cashflow> = of();
  cashflowActual$: Observable<Cashflow[]>;
  selectedTab: 'add' | 'actual' | 'archive' = 'add';

  private cashFlowService = inject(CashFlowServiceService);

  constructor(
    private fb: FormBuilder,
    private authService: AuthService
  ) {
    this.cashflowActual$ = of([]);
  }

  ngOnInit(): void {
    this.cashflows$ = this.cashFlowService.getCashFlowListAll();
    this.cashflowActual$ = this.cashFlowService
      .getCashFlowLast()
      .pipe(map(cashflow => (cashflow ? [cashflow] : [])));
    this.loadForeignKeyData();
    this.cashFlowForm = this.fb.group({
      cash_flow_name: ['', Validators.required],
      cash_flow_note: [''],
      amount: [0, Validators.required],
      invoice: [null, Validators.required],
      dev: [null, Validators.required],
      cashflowgroup: [null, Validators.required],
      cash_flow_date: ['', Validators.required],
    });
  }

  selectTab(tab: 'add' | 'actual' | 'archive') {
    this.selectedTab = tab;
  }
  loadForeignKeyData(): void {
    this.cashFlowService.getForeignKeyData().subscribe(
      data => {
        this.invoices = data.invoices;
        this.devs = data.devs;
        this.cashFlowGroups = data.cashflowgroup;

        this.fieldConfigs = [
          { label: 'Költség neve', controlName: 'cash_flow_name', type: 'text' },
          { label: 'Megjegyzés', controlName: 'cash_flow_note', type: 'text' },
          { label: 'Összeg', controlName: 'amount', type: 'number' },
          { label: 'Dátum', controlName: 'cash_flow_date', type: 'date' },
          {
            label: 'Pénznem',
            controlName: 'dev',
            type: 'select',
            options: this.devs,
            optionLabel: 'dev_name',
          },
          {
            label: 'Számla',
            controlName: 'invoice',
            type: 'select',
            options: this.invoices,
            optionLabel: 'invoice_name',
          },
          {
            label: 'Költség csoport',
            controlName: 'cashflowgroup',
            type: 'select',
            options: this.cashFlowGroups,
            optionLabel: 'cash_flow_group_name',
          },
        ];

        this.buildForm();
      },
      error => {
        console.error('Hiba a ForeignKey adatok betöltésekor:', error);
      }
    );
  }
  buildForm(): void {
    const formGroupConfig: { [key: string]: any } = {};
    this.fieldConfigs.forEach(field => {
      formGroupConfig[field.controlName] = ['', Validators.required];
    });
    this.cashFlowForm = this.fb.group(formGroupConfig);
  }

  addCost(): void {
    if (this.cashFlowForm.valid) {
      const newCashflow: CashFlowResponse = this.cashFlowForm.value;
      newCashflow.create_cash_flow_date = new Date();
      newCashflow.user = this.authService.getUserId();
      this.cashFlowService.create(newCashflow).subscribe(
        data => {
          this.cashFlowResponse.push(data);
          this.cashFlowForm.reset(); // űrlap törlése
        },
        error => {
          console.error('Hiba a költség hozzáadásakor:', error);
        }
      );
    } else {
      console.log('hiba');
      console.log(this.cashFlowForm.value);
    }
  }
}
