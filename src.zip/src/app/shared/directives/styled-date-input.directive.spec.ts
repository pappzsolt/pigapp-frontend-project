import { StyledDateInputDirective } from './styled-date-input.directive';

describe('StyledDateInputDirective', () => {
  it('should create an instance', () => {
    const directive = new StyledDateInputDirective();
    expect(directive).toBeTruthy();
  });
});
