import { TailwindStyledTableDirective } from './tailwind-styled-table.directive';

describe('TailwindStyledTableDirective', () => {
  it('should create an instance', () => {
    const directive = new TailwindStyledTableDirective();
    expect(directive).toBeTruthy();
  });
});
