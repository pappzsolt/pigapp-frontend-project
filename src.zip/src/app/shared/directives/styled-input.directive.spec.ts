import { StyledInputDirective } from './styled-input.directive';

describe('StyledInputDirective', () => {
  it('should create an instance', () => {
    const directive = new StyledInputDirective();
    expect(directive).toBeTruthy();
  });
});
