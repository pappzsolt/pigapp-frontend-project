import { InputStyleDirective } from './input-style.directive';

describe('InputStyleDirective', () => {
  it('should create an instance', () => {
    const directive = new InputStyleDirective();
    expect(directive).toBeTruthy();
  });
});
