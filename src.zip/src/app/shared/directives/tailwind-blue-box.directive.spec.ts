import { TailwindBlueBoxDirective } from './tailwind-blue-box.directive';

describe('TailwindBlueBoxDirective', () => {
  it('should create an instance', () => {
    const directive = new TailwindBlueBoxDirective();
    expect(directive).toBeTruthy();
  });
});
