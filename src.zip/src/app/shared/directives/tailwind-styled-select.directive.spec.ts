import { TailwindStyledSelectDirective } from './tailwind-styled-select.directive';

describe('TailwindStyledSelectDirective', () => {
  it('should create an instance', () => {
    const directive = new TailwindStyledSelectDirective();
    expect(directive).toBeTruthy();
  });
});
